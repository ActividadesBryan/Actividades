﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EjemploMVC.Models;

namespace EjemploMVC.Controllers
{
    public class ConversionController : Controller
    {
        // GET: Temperatura
        public ActionResult Conversiones()
        {
            return View();
        }

        // POST: Prueba/Index
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Conversiones(Conversion obConver)
        {
            double conver = 0;
            if (obConver.Tconver == 1)
            {
                conver = obConver.cantidad + 273.15;
            }
            else if (obConver.Tconver == 2)
            {
                conver = obConver.cantidad - 273.15;
            }
            else if (obConver.Tconver == 3)
            {
                conver = obConver.cantidad * 2.205;
            }
            else if (obConver.Tconver == 4)
            {
                conver = obConver.cantidad / 2.205;
            }
            else if (obConver.Tconver == 5)
            {
                conver = obConver.cantidad * 39.37;
            }

            ViewBag.conversion = conver;
            return View(obConver);
        }
    }
}