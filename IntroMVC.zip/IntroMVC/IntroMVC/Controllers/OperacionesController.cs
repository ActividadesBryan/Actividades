﻿using IntroMVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IntroMVC.Controllers
{
    public class OperacionesController : Controller
    {
        // GET: Operaciones
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Suma()
        {
            Datos objModel = new Datos();
            objModel.VariableA = 3;
            objModel.VariableB = 6;
            objModel.Resultado = objModel.VariableA + objModel.VariableB;
            ViewData["Resultado"] = objModel.Resultado;
            return View();
        }

        public ActionResult Resta()
        {
            Datos objModel = new Datos();
            objModel.VariableA = double.Parse(Request.Form["Valor1"].ToString());
            objModel.VariableB = double.Parse(Request.Form["Valor2"].ToString());
            objModel.Resultado = objModel.VariableA - objModel.VariableB;
            return View("Resta",objModel);
        }

        public ActionResult Multiplicacion()
        {
            Datos objModel = new Datos();
            objModel.VariableA = double.Parse(Request.Form["Valor3"].ToString());
            objModel.VariableB = double.Parse(Request.Form["Valor4"].ToString());
            objModel.Resultado = objModel.VariableA * objModel.VariableB;
            return View("Multiplicacion", objModel);
        }

        public ActionResult Division()
        {
            Datos objModel = new Datos();
            objModel.VariableA = 6;
            objModel.VariableB = 3;
            objModel.Resultado = objModel.VariableA / objModel.VariableB;
            ViewData["Resultado"] = objModel.Resultado;
            return View();
        }
    }
}