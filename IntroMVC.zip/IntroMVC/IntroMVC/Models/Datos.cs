﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntroMVC.Models
{
    public class Datos
    {
        public double VariableA { get; set; }
        public double VariableB { get; set; }
        public double Resultado { get; set; }
    }
}